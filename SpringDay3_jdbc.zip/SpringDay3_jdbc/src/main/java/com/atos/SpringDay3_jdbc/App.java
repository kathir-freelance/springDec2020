package com.atos.SpringDay3_jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("springs.xml");
        DbConfig db=(DbConfig)ctx.getBean("dbconfig");
        DataSource ds=db.getDs();
        JdbcTemplate jdbc=new JdbcTemplate(ds);
      //  Integer i=jdbc.queryForObject("select count(*) from Vehicle",Integer.class);
       // System.out.println(i);
        //List<Map<String, Object>> data= jdbc.queryForList("select * from Vehicle");
        //System.out.println(data);
     //   String data= jdbc.queryForObject("select veh_name from Vehicle where vid=1111",String.class);
     //   System.out.println(data);
        
        //List<Vehicle> li=jdbc.query("select * From Vehicle",new VehicleRowMapper());
        //System.out.println(li);
        
      //  int s=jdbc.update("insert into vehicle values(1113,'nissan',6)");
    //    int s=jdbc.update("insert into vehicle values(?,?,?)",new Object[]{1114,"renault",6});
     //   System.out.println(s +" insrerted");
       List<String> names=jdbc.queryForList("select Veh_name from vehicle where vid=?",new Object[]{1114},String.class);
        System.out.println(names);
    }
}

class VehicleRowMapper implements RowMapper<Vehicle>{

	public Vehicle mapRow(ResultSet rs, int arg1) throws SQLException {
		
		Vehicle vh=new Vehicle(rs.getInt(1),rs.getString(2),rs.getInt(3));
		
		return vh;
	}

	
	
	
}
