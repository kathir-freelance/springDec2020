package com.atos.springapp1;

public class Employee {

	private int empId;
	private String name;
	private Address addr;
	
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	public Address getAddr() {
		return addr;
	}
	
	public Employee() {
		System.out.println("object created");
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + "+address+]"+addr;
	}
	
	
}
