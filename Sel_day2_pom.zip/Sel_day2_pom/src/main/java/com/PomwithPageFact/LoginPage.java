package com.PomwithPageFact;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {

	@FindBy(how=How.ID,using="txtUsername")
	WebElement name;
	@FindBy(how=How.ID,using="txtPassword")
	WebElement password;
	@FindBy(how=How.ID,using="btnLogin")
	WebElement btn;
	WebDriver driver=null;
	
	public LoginPage(WebDriver driver) {
			
		this.driver=driver;
	}	
	public void login(String un,String pwd){
		System.out.println(name);
		name.sendKeys(un);
		password.sendKeys(pwd);
		btn.click();
	}
}