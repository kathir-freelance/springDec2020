package com.atos.Sel_day2_pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.PomwithPageFact.LoginPage;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\DELL\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();		
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
	
    	//LoginPage login=new LoginPage(driver);
    	//login.typeUserName("admin");
    	//login.typePassword("admin123");
    	//login.triggerLogin();
			LoginPage log=new LoginPage(driver);
			log.login("admin", "admin123");
    }
}
