package com.atos.Sel_day2_pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	WebDriver driver=null;
	
	By username=By.id("txtUsername");
	By pass=By.id("txtPassword");
	By btn=By.id("btnLogin");

	public LoginPage(WebDriver driver) {
		this.driver=driver;
	}
	
	public void typeUserName(String name){
		driver.findElement(username).sendKeys(name);
	}
	public void typePassword(String password){
		driver.findElement(pass).sendKeys(password);
	}
	public void triggerLogin(){
		driver.findElement(btn).click();
	}
}

