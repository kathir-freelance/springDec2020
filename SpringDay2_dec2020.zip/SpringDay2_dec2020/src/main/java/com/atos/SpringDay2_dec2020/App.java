package com.atos.SpringDay2_dec2020;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext ctx=null;
        ctx=new ClassPathXmlApplicationContext("springs.xml");
 //   BeanFactory ctx=new XmlBeanFactory(new ClassPathResource("springs.xml"));
    	
       /*Engine engine1=(Engine) ctx.getBean("engine");
       System.out.println(engine1);*/
       //Car car1=(Car) ctx.getBean("car");
     //  car1.setCarName("Hyundai"); //this doesnt affect second object of car as its prototype
       //System.out.println(car1);
       
       //Car car2=(Car) ctx.getBean("car");
       //System.out.println(car2);
        //Car car3=(Car) ctx.getBean("car");
        Car car3=(Car) ctx.getBean("carObj");
        System.out.println(car3.getEngine());
        System.out.println(car3);

    }
}
