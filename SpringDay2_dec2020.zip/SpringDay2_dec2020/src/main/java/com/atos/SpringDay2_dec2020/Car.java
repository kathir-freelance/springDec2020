package com.atos.SpringDay2_dec2020;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value="carObj")
@Scope(value="prototype")
public class Car {

	@Value("1234")
	private int regNum;
	@Value("Ford")
	private String carName;
	@Autowired(required=false)	
	private Engine engine;
	
	public Engine getEngine() {
		return engine;
	}
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	public int getRegNum() {
		return regNum;
	}


	public void setRegNum(int regNum) {
		this.regNum = regNum;
	}


	public String getCarName() {
		return carName;
	}


	public void setCarName(String carName) {
		this.carName = carName;
	}


	public Car() {
	System.out.println("car created");
	}


	@Override
	public String toString() {
		return "Car [regNum=" + regNum + ", carName=" + carName + "]";
	}
	
	
}
