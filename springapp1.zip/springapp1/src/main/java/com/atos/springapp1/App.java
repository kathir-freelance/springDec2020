package com.atos.springapp1;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App 
{
    public static void main( String[] args )
    {
       // System.out.println( "Hello World!" );
    	BeanFactory beanFactory=null;
    	Resource res=new ClassPathResource("springs.xml");//locate the file as container cant do that
    	beanFactory=new XmlBeanFactory(res)	;
   /* 	Employee employee1=(Employee)beanFactory.getBean("emp1");//on-demand
    	System.out.println(employee1);
    	Employee employee2=(Employee)beanFactory.getBean("emp1");
    	System.out.println(employee2);
   */ 	
    //	Employee employee3=(Employee)beanFactory.getBean("emp2");
    //	System.out.println(employee3);
   
    //on demand i need new objects every time , only emp1 ref is there in xml
     	Employee employee1=(Employee)beanFactory.getBean("emp1");//on-demand
    	employee1.setEmpId(1001);
    	employee1.setName("ajay");
     	System.out.println(employee1);
    	
    	Employee employee2=(Employee)beanFactory.getBean("emp1");
    	System.out.println(employee2);
   
    
    }
}
