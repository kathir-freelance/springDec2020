package com.atos.springapp1;

public class Department {

}
